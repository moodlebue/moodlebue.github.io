<?php 
$plugin->version = 2020051300;
$plugin->component = 'block_rce';